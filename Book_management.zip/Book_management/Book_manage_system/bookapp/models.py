from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Book(models.Model):
    Book_title = models.CharField(max_length=100)
    Book_author = models.CharField(max_length=100)
    Book_price = models.IntegerField()
    Book_publisher = models.CharField(max_length=100)
    Book_image = models.ImageField(upload_to='book_coves/')

def __str__(self):
    return self.Book_title


class Customer(models.Model):
    Customer_name = models.CharField(max_length=100)
    Customer_email = models.CharField(max_length=100)
    Customer_phone = models.IntegerField()
    Customer_address= models.CharField(max_length=300)

def __str__(self):
    return self.Customer_name

class Order(models.Model):
    Order_id = models.IntegerField()
    Order_date = models.DateField(max_length=10)
    Order_status = models.CharField(max_length=100)
    customer= models.ForeignKey(Customer,on_delete=models.CASCADE)
    book=models.ForeignKey(Book,on_delete=models.CASCADE)

def __str__(self):
    return self.Order_id




